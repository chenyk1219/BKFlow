# BKFlow 前端画布与后端 Pipeline Tree 转换详解

## 一、概述

BKFlow 流程引擎采用前后端分离架构，前端使用可视化画布进行流程编排，后端使用 Pipeline Tree 数据结构进行流程执行。两者之间需要进行双向转换：

- **前端 → 后端**：画布数据（location + line）→ Pipeline Tree（activities + flows + gateways）
- **后端 → 前端**：Pipeline Tree → 画布数据（自动布局算法）

## 二、核心数据结构

### 2.1 Pipeline Tree 数据结构（后端）

Pipeline Tree 是后端流程引擎的核心数据结构，包含以下主要字段：

```json
{
  "activities": {},        // 任务节点字典
  "gateways": {},         // 网关节点字典
  "flows": {},            // 连线字典
  "start_event": {},      // 开始节点
  "end_event": {},        // 结束节点
  "constants": {},        // 全局变量
  "outputs": [],          // 输出变量
  "location": [],         // 前端画布位置信息（可选）
  "line": [],             // 前端画布连线信息（可选）
  "canvas_mode": ""       // 画布模式：horizontal/vertical/stage
}
```

### 2.2 前端画布数据结构

前端画布使用两个核心数组存储节点和连线信息：

#### location 数组（节点位置）
```json
[
  {
    "id": "node123abc",           // 节点ID，格式：n[0-9a-z]+
    "type": "tasknode",           // 节点类型
    "name": "任务节点1",           // 节点名称
    "x": 240,                     // X坐标
    "y": 140,                     // Y坐标
    "stage_name": "",             // 阶段名称
    "group": "",                  // 分组信息
    "icon": ""                    // 图标
  }
]
```

#### line 数组（连线）
```json
[
  {
    "id": "line456def",           // 连线ID，格式：l[0-9a-z]+
    "source": {
      "id": "node123abc",         // 源节点ID
      "arrow": "Right"            // 源端点位置：Top/Right/Bottom/Left
    },
    "target": {
      "id": "node789ghi",         // 目标节点ID
      "arrow": "Left"             // 目标端点位置
    }
  }
]
```

## 三、节点类型映射

### 3.1 前端类型 → 后端类型

| 前端类型 (location.type) | 后端类型 (node.type) | 说明 |
|------------------------|---------------------|------|
| startpoint | EmptyStartEvent | 开始节点 |
| endpoint | EmptyEndEvent | 结束节点 |
| tasknode | ServiceActivity | 标准任务节点 |
| subflow | SubProcess | 子流程节点 |
| branchgateway | ExclusiveGateway | 分支网关（互斥） |
| parallelgateway | ParallelGateway | 并行网关 |
| conditionalparallelgateway | ConditionalParallelGateway | 条件并行网关 |
| convergegateway | ConvergeGateway | 汇聚网关 |

**代码位置**：
- 前端：`frontend/src/store/modules/template.js` (ATOM_TYPE_DICT)
- 前端：`frontend/src/utils/formatLayout.js` (NODE_TYPE_MAPPING)
- 后端：`bkflow/pipeline_web/drawing_new/constants.py` (PIPELINE_ELEMENT_TO_WEB)

## 四、详细字段说明

### 4.1 Activities（任务节点）

#### ServiceActivity（标准任务节点）
```json
{
  "node123abc": {
    "id": "node123abc",
    "type": "ServiceActivity",
    "name": "任务节点名称",
    "incoming": ["line001"],              // 输入连线ID（数组）
    "outgoing": "line002",                // 输出连线ID（字符串）
    "optional": true,                     // 是否可选
    "error_ignorable": false,             // 是否忽略错误
    "retryable": true,                    // 是否可重试
    "skippable": true,                    // 是否可跳过
    "stage_name": "",                     // 阶段名称
    "component": {
      "code": "sleep_timer",              // 组件代码
      "version": "v1.0",                  // 组件版本
      "data": {                           // 组件参数
        "param1": {
          "hook": false,                  // 是否勾选为全局变量
          "need_render": true,            // 是否需要渲染
          "value": "参数值"
        }
      }
    },
    "auto_retry": {                       // 自动重试配置
      "enable": false,
      "interval": 0,
      "times": 1
    },
    "timeout_config": {                   // 超时配置
      "enable": false,
      "seconds": 10,
      "action": "forced_fail"
    },
    "labels": []                          // 标签
  }
}
```

#### SubProcess（子流程节点）
```json
{
  "node456def": {
    "id": "node456def",
    "type": "SubProcess",
    "name": "子流程名称",
    "incoming": ["line003"],
    "outgoing": "line004",
    "optional": true,
    "template_id": "template123",         // 子流程模板ID
    "version": "v1.0",                    // 子流程版本
    "constants": {},                      // 子流程变量
    "pipeline": {}                        // 子流程的完整 pipeline tree
  }
}
```

### 4.2 Gateways（网关节点）

#### ExclusiveGateway（分支网关）
```json
{
  "node789ghi": {
    "id": "node789ghi",
    "type": "ExclusiveGateway",
    "name": "分支网关",
    "incoming": "line005",                // 输入连线（字符串或数组）
    "outgoing": ["line006", "line007"],   // 输出连线（数组）
    "conditions": {                       // 分支条件
      "line006": {
        "evaluate": "${var1} == 'value1'"
      },
      "line007": {
        "evaluate": "${var1} == 'value2'"
      }
    },
    "default_condition": {                // 默认分支
      "flow_id": "line007"
    }
  }
}
```

#### ParallelGateway（并行网关）
```json
{
  "node111aaa": {
    "id": "node111aaa",
    "type": "ParallelGateway",
    "name": "并行网关",
    "incoming": "line008",
    "outgoing": ["line009", "line010", "line011"]  // 所有分支并行执行
  }
}
```

#### ConditionalParallelGateway（条件并行网关）
```json
{
  "node222bbb": {
    "id": "node222bbb",
    "type": "ConditionalParallelGateway",
    "name": "条件并行网关",
    "incoming": "line012",
    "outgoing": ["line013", "line014"],
    "conditions": {                       // 满足条件的分支并行执行
      "line013": {
        "evaluate": "${var2} > 10"
      },
      "line014": {
        "evaluate": "${var3} == true"
      }
    }
  }
}
```

#### ConvergeGateway（汇聚网关）
```json
{
  "node333ccc": {
    "id": "node333ccc",
    "type": "ConvergeGateway",
    "name": "汇聚网关",
    "incoming": ["line015", "line016"],   // 多个输入连线
    "outgoing": "line017"                 // 单个输出连线
  }
}
```

### 4.3 Flows（连线）

```json
{
  "line001": {
    "id": "line001",
    "source": "node123abc",               // 源节点ID
    "target": "node456def",               // 目标节点ID
    "is_default": false                   // 是否为默认分支
  }
}
```

### 4.4 Start Event（开始节点）

```json
{
  "id": "node000start",
  "type": "EmptyStartEvent",
  "name": "",
  "incoming": "",                         // 开始节点无输入
  "outgoing": "line001"                   // 单个输出连线
}
```

### 4.5 End Event（结束节点）

```json
{
  "id": "node999end",
  "type": "EmptyEndEvent",
  "name": "",
  "incoming": ["line020"],                // 可以有多个输入
  "outgoing": ""                          // 结束节点无输出
}
```

### 4.6 Constants（全局变量）

```json
{
  "${var_name}": {
    "key": "${var_name}",                 // 变量key，格式：${xxx}
    "name": "变量名称",
    "desc": "变量描述",
    "custom_type": "",                    // 自定义类型
    "source_type": "component_inputs",    // 来源类型：component_inputs/component_outputs/custom/system
    "source_tag": "sleep_timer.bk_timing",// 来源标签
    "source_info": {                      // 来源信息
      "node123abc": ["param1"]
    },
    "value": "默认值",
    "show_type": "show",                  // 显示类型：show/hide
    "validation": "",                     // 校验规则
    "index": 0                            // 排序索引
  }
}
```

## 五、前端 → 后端转换逻辑

### 5.1 转换流程概述

前端画布保存时，需要将 `location` 和 `line` 数组转换为后端的 `activities`、`gateways`、`flows` 等字段。

**核心代码位置**：`frontend/src/store/modules/template.js`

### 5.2 节点转换逻辑

#### 5.2.1 开始节点转换
```javascript
// 代码位置：frontend/src/store/modules/template.js (generateStartNode)
const generateStartNode = (location, line) => ({
  id: location.id,
  incoming: '',              // 开始节点无输入
  name: '',
  outgoing: line.id,         // 从 line 数组中找到 source 为该节点的连线
  type: 'EmptyStartEvent',
});
```

#### 5.2.2 结束节点转换
```javascript
// 代码位置：frontend/src/store/modules/template.js (generateEndNode)
const generateEndNode = (location, line) => ({
  id: location.id,
  incoming: [line.id],       // 从 line 数组中找到 target 为该节点的连线
  name: '',
  outgoing: '',              // 结束节点无输出
  type: 'EmptyEndEvent',
});
```

#### 5.2.3 任务节点转换
```javascript
// 任务节点从 location 转换到 activities
// 代码位置：frontend/src/store/modules/template.js
{
  [location.id]: {
    id: location.id,
    type: 'ServiceActivity',  // 根据 location.type 映射
    name: location.name,
    incoming: findIncomingLines(location.id),  // 查找所有 target 为该节点的连线
    outgoing: findOutgoingLine(location.id),   // 查找 source 为该节点的连线
    optional: true,
    error_ignorable: false,
    retryable: true,
    skippable: true,
    component: {
      code: undefined,
      version: undefined,
      data: {}
    },
    // ... 其他配置
  }
}
```

#### 5.2.4 网关节点转换
```javascript
// 网关节点从 location 转换到 gateways
// 分支网关示例
{
  [location.id]: {
    id: location.id,
    type: 'ExclusiveGateway',  // 根据 location.type 映射
    name: location.name,
    incoming: findIncomingLines(location.id),
    outgoing: findOutgoingLines(location.id),  // 网关可能有多个输出
    conditions: {},  // 分支条件，需要用户配置
  }
}

// 汇聚网关示例
{
  [location.id]: {
    id: location.id,
    type: 'ConvergeGateway',
    name: location.name,
    incoming: findIncomingLines(location.id),  // 汇聚网关有多个输入
    outgoing: findOutgoingLine(location.id),   // 单个输出
  }
}
```

### 5.3 连线转换逻辑

```javascript
// line 数组转换为 flows 对象
// 代码位置：frontend/src/store/modules/template.js

// 前端 line 格式
const line = {
  id: "line001",
  source: { id: "node123", arrow: "Right" },
  target: { id: "node456", arrow: "Left" }
};

// 转换为后端 flows 格式
const flows = {
  "line001": {
    id: "line001",
    source: "node123",      // 只保留节点ID
    target: "node456",      // 只保留节点ID
    is_default: false       // 是否为默认分支
  }
};
```

**转换规则**：
1. 连线的 `arrow` 信息（Top/Right/Bottom/Left）仅用于前端渲染，后端不需要
2. 后端通过节点的 `incoming` 和 `outgoing` 字段建立连接关系
3. 分支网关的默认分支通过 `default_condition.flow_id` 标识

### 5.4 incoming/outgoing 计算逻辑

```javascript
// 代码位置：frontend/src/store/modules/template.js

// 计算节点的输入连线
function findIncomingLines(nodeId, lines) {
  const incomingLines = lines
    .filter(line => line.target.id === nodeId)
    .map(line => line.id);

  // 如果只有一个输入，返回字符串；多个输入返回数组
  if (incomingLines.length === 0) return '';
  if (incomingLines.length === 1) return incomingLines[0];
  return incomingLines;
}

// 计算节点的输出连线
function findOutgoingLines(nodeId, lines) {
  const outgoingLines = lines
    .filter(line => line.source.id === nodeId)
    .map(line => line.id);

  // 普通节点只有一个输出，返回字符串
  // 网关节点有多个输出，返回数组
  if (outgoingLines.length === 0) return '';
  if (outgoingLines.length === 1) return outgoingLines[0];
  return outgoingLines;
}
```

### 5.5 完整转换示例

**前端画布数据**：
```json
{
  "location": [
    { "id": "n001", "type": "startpoint", "x": 40, "y": 150 },
    { "id": "n002", "type": "tasknode", "name": "任务1", "x": 240, "y": 140 },
    { "id": "n003", "type": "branchgateway", "name": "分支", "x": 440, "y": 150 },
    { "id": "n004", "type": "tasknode", "name": "任务2", "x": 640, "y": 100 },
    { "id": "n005", "type": "tasknode", "name": "任务3", "x": 640, "y": 200 },
    { "id": "n006", "type": "convergegateway", "name": "汇聚", "x": 840, "y": 150 },
    { "id": "n007", "type": "endpoint", "x": 1040, "y": 150 }
  ],
  "line": [
    { "id": "l001", "source": { "id": "n001", "arrow": "Right" }, "target": { "id": "n002", "arrow": "Left" } },
    { "id": "l002", "source": { "id": "n002", "arrow": "Right" }, "target": { "id": "n003", "arrow": "Left" } },
    { "id": "l003", "source": { "id": "n003", "arrow": "Bottom" }, "target": { "id": "n004", "arrow": "Left" } },
    { "id": "l004", "source": { "id": "n003", "arrow": "Bottom" }, "target": { "id": "n005", "arrow": "Left" } },
    { "id": "l005", "source": { "id": "n004", "arrow": "Right" }, "target": { "id": "n006", "arrow": "Bottom" } },
    { "id": "l006", "source": { "id": "n005", "arrow": "Right" }, "target": { "id": "n006", "arrow": "Bottom" } },
    { "id": "l007", "source": { "id": "n006", "arrow": "Right" }, "target": { "id": "n007", "arrow": "Left" } }
  ]
}
```

**转换后的 Pipeline Tree**：
```json
{
  "start_event": {
    "id": "n001",
    "type": "EmptyStartEvent",
    "incoming": "",
    "outgoing": "l001"
  },
  "activities": {
    "n002": {
      "id": "n002",
      "type": "ServiceActivity",
      "name": "任务1",
      "incoming": ["l001"],
      "outgoing": "l002",
      "component": { "code": "", "data": {} }
    },
    "n004": {
      "id": "n004",
      "type": "ServiceActivity",
      "name": "任务2",
      "incoming": ["l003"],
      "outgoing": "l005",
      "component": { "code": "", "data": {} }
    },
    "n005": {
      "id": "n005",
      "type": "ServiceActivity",
      "name": "任务3",
      "incoming": ["l004"],
      "outgoing": "l006",
      "component": { "code": "", "data": {} }
    }
  },
  "gateways": {
    "n003": {
      "id": "n003",
      "type": "ExclusiveGateway",
      "name": "分支",
      "incoming": "l002",
      "outgoing": ["l003", "l004"],
      "conditions": {
        "l003": { "evaluate": "" },
        "l004": { "evaluate": "" }
      }
    },
    "n006": {
      "id": "n006",
      "type": "ConvergeGateway",
      "name": "汇聚",
      "incoming": ["l005", "l006"],
      "outgoing": "l007"
    }
  },
  "flows": {
    "l001": { "id": "l001", "source": "n001", "target": "n002", "is_default": false },
    "l002": { "id": "l002", "source": "n002", "target": "n003", "is_default": false },
    "l003": { "id": "l003", "source": "n003", "target": "n004", "is_default": false },
    "l004": { "id": "l004", "source": "n003", "target": "n005", "is_default": false },
    "l005": { "id": "l005", "source": "n004", "target": "n006", "is_default": false },
    "l006": { "id": "l006", "source": "n005", "target": "n006", "is_default": false },
    "l007": { "id": "l007", "source": "n006", "target": "n007", "is_default": false }
  },
  "end_event": {
    "id": "n007",
    "type": "EmptyEndEvent",
    "incoming": ["l007"],
    "outgoing": ""
  }
}
```

