# 后端 Pipeline Tree 转前端画布详解

## 一、转换流程概述

后端 Pipeline Tree 转换为前端画布数据主要通过自动布局算法实现，核心流程如下：

```
Pipeline Tree (activities + flows + gateways)
    ↓
自动布局算法 (formatLayout)
    ↓
画布数据 (location + line)
    ↓
渲染数据 (X6 Graph JSON)
```

**核心代码文件**：
- 前端：`frontend/src/utils/formatLayout.js` - 自动布局算法
- 前端：`frontend/src/utils/graphJson.js` - 画布数据转换
- 后端：`bkflow/pipeline_web/drawing_new/drawing.py` - 后端布局算法

## 二、前端自动布局算法

### 2.1 核心函数：formatLayout

**文件位置**：`frontend/src/utils/formatLayout.js`

```javascript
export const formatLayout = (nodes, flows) => {
  // 1. 初始化状态
  initState(nodes, flows);
  
  // 2. 查找开始节点
  const startNode = findStartNode();
  
  // 3. 从开始节点递归布局
  updateFlowLayout(startNode, LAYOUT_CONFIG.baseX, LAYOUT_CONFIG.baseY);
  
  // 4. 生成结果
  return generateResult();
};
```

### 2.2 布局配置常量

```javascript
const LAYOUT_CONFIG = {
  baseX: 40,              // 起始X坐标
  baseY: 134,             // 起始Y坐标
  horizontalSpacing: 46,  // 水平间距
  verticalSpacing: 46,    // 垂直间距
  branchOffset: 168,      // 分支偏移量
};

const NODE_SIZES = {
  ServiceActivity: { width: 154, height: 54 },    // 任务节点尺寸
  SubProcess: { width: 154, height: 54 },         // 子流程节点尺寸
  default: { width: 34, height: 34 },             // 其他节点尺寸（网关、事件）
};
```

### 2.3 输入数据格式

```javascript
// nodes: 所有节点的字典（包含 activities、gateways、start_event、end_event）
const nodes = {
  "n001": {
    id: "n001",
    type: "EmptyStartEvent",
    name: "",
    incoming: "",
    outgoing: "l001"
  },
  "n002": {
    id: "n002",
    type: "ServiceActivity",
    name: "任务1",
    incoming: ["l001"],
    outgoing: "l002"
  },
  // ... 更多节点
};

// flows: 连线字典
const flows = {
  "l001": {
    id: "l001",
    source: "n001",
    target: "n002",
    is_default: false
  },
  // ... 更多连线
};
```

### 2.4 核心布局逻辑

#### 2.4.1 递归布局函数

```javascript
const updateFlowLayout = (node, x, y) => {
  // 1. 如果节点已访问，跳过
  if (!node || state.visited.has(node.id)) return;
  
  // 2. 记录节点位置
  recordNodePosition(node, x, y);
  
  // 3. 如果是结束节点，停止递归
  if (node.type === 'EmptyEndEvent') return;
  
  // 4. 获取节点的所有输出边
  const edges = getOutgoingEdges(node.id);
  if (!edges.length) return;
  
  // 5. 根据输出边数量选择处理方式
  if (edges.length > 1) {
    // 多个输出：分支节点（网关）
    processBranchNode(node, edges);
  } else {
    // 单个输出：普通节点
    processSingleEdge(node, edges[0]);
  }
};
```

#### 2.4.2 单边处理

```javascript
const processSingleEdge = (node, edge) => {
  const targetNode = state.nodes[edge.target];
  const position = calculateNodePosition(node, targetNode);
  
  // 递归布局目标节点
  updateFlowLayout(targetNode, position.x, position.y);
  
  // 更新边的端点信息
  updateEdgePort(edge);
};

// 计算下一个节点的位置
const calculateNodePosition = (sourceNode, targetNode) => {
  const sourcePos = state.nodePositions.get(sourceNode.id);
  const targetSize = getNodeSize(targetNode);
  
  // X坐标 = 源节点右边 + 水平间距
  const x = sourcePos.x + sourcePos.width + LAYOUT_CONFIG.horizontalSpacing;
  
  // Y坐标 = 源节点中心对齐
  const y = sourcePos.y + sourcePos.height / 2 - targetSize.height / 2;
  
  return { x, y };
};
```

#### 2.4.3 分支处理

```javascript
const processBranchNode = (node, edges) => {
  // 1. 对分支进行排序（按深度降序）
  const sortedEdges = sortBranches(edges);
  
  // 2. 布局每个分支
  sortedEdges.forEach((edge, index) => {
    const targetNode = state.nodes[edge.target];
    const position = calculateNodePosition(node, targetNode, index, sortedEdges);
    
    // 递归布局分支
    updateFlowLayout(targetNode, position.x, position.y);
    
    // 更新边的端点
    updateEdgePort(edge, index);
  });
  
  // 3. 调整分支位置，避免重叠
  adjustBranchPositions(sortedEdges);
};
```

#### 2.4.4 分支排序算法

```javascript
const sortBranches = (edges) => {
  const branchDepths = new Map();
  
  // 计算每个分支的深度
  edges.forEach((edge) => {
    const visited = new Set();
    const depth = calculateBranchDepth(edge.target, visited);
    branchDepths.set(edge.id, depth);
    state.branchVisitedNodes.set(edge.id, visited);
  });
  
  // 如果所有分支深度相同，保持原顺序
  if (new Set(branchDepths.values()).size === 1) {
    return edges;
  }
  
  // 按深度降序排序（深度大的分支在上方）
  return [...edges].sort((a, b) => branchDepths.get(b.id) - branchDepths.get(a.id));
};

// 递归计算分支深度
const calculateBranchDepth = (nodeId, visited) => {
  if (!nodeId || visited.has(nodeId)) return 0;
  visited.add(nodeId);
  
  const node = state.nodes[nodeId];
  if (!node || node.type === 'EmptyEndEvent') return 0;
  
  const edges = getOutgoingEdges(node.id);
  if (!edges.length) return 1;
  
  let maxDepth = 0;
  edges.forEach((edge) => {
    maxDepth = Math.max(maxDepth, calculateBranchDepth(edge.target, visited));
  });
  
  return 1 + maxDepth;
};
```

#### 2.4.5 分支位置调整

```javascript
const adjustBranchPositions = (edges) => {
  edges.reduce((acc, edge, index) => {
    // 第一个分支不需要调整
    if (index === 0) {
      return { [index]: getBranchNodes(edge, null) };
    }
    
    // 获取当前分支的所有节点
    const convergeNode = findConvergenceNode(edges.slice(0, index + 1));
    const branchNodes = getBranchNodes(edge, convergeNode);
    
    if (!branchNodes.length) return acc;
    
    // 获取前一个分支的位置信息
    const { y: prevY, height: prevHeight } = state.nodePositions.get(edges[index - 1].target);
    
    // 获取前面所有分支的节点
    const frontBranchNodes = [...new Set(Object.values(acc).flat())];
    
    // 检查是否有节点在前一个分支下方
    const nodesBelowPrevBranch = frontBranchNodes
      .map(nodeId => state.nodePositions.get(nodeId))
      .filter(nodePos => nodePos.y > (prevY + prevHeight));
    
    // 如果有重叠，重新定位当前分支
    const firstNode = state.nodes[branchNodes[0]];
    const firstNodePos = state.nodePositions.get(firstNode.id);
    
    if (nodesBelowPrevBranch.length === 0) {
      // 简单调整：紧贴前一个分支
      if (firstNodePos.y > (prevY + prevHeight + LAYOUT_CONFIG.verticalSpacing)) {
        resetNodesAndReposition(branchNodes, firstNode, {
          x: firstNodePos.x,
          y: prevY + prevHeight + LAYOUT_CONFIG.horizontalSpacing,
        });
      }
    } else {
      // 复杂调整：检查是否与前面分支的节点重叠
      const minX = Math.min(...nodesBelowPrevBranch.map(node => node.x));
      const maxX = calculateMaxXPosition([...branchNodes, convergeNode]);
      
      if ((maxX + LAYOUT_CONFIG.horizontalSpacing) < minX) {
        resetNodesAndReposition(branchNodes, firstNode, {
          x: firstNodePos.x,
          y: prevY + prevHeight + LAYOUT_CONFIG.horizontalSpacing,
        });
      }
    }
    
    return Object.assign(acc, { [index]: branchNodes });
  }, {});
};
```

### 2.5 边端点计算

```javascript
const updateEdgePort = (edge, index = 0) => {
  // 源端点：第一个分支从右侧出，其他分支从底部出
  const sourcePort = index === 0 ? 'Right' : 'Bottom';

  // 目标端点：第一次访问从左侧进，后续访问从底部进（汇聚网关）
  const targetPort = state.visitedConvergeNode.has(edge.target) ? 'Bottom' : 'Left';

  // 标记目标节点已访问
  state.visitedConvergeNode.add(edge.target);

  edge.sourcePort = sourcePort;
  edge.targetPort = targetPort;
};
```

**端点位置说明**：
- `Top`: 节点顶部
- `Right`: 节点右侧
- `Bottom`: 节点底部
- `Left`: 节点左侧

### 2.6 输出数据格式

```javascript
const generateResult = () => ({
  locations: generateLocations(),
  lines: generateLines(),
});

// 生成 location 数组
const generateLocations = () => Array.from(state.nodePositions.keys()).map(nodeId => ({
  id: nodeId,
  x: state.nodePositions.get(nodeId).x,
  y: state.nodePositions.get(nodeId).y,
  type: NODE_TYPE_MAPPING[state.nodes[nodeId].type] || '',  // 后端类型转前端类型
  name: state.nodes[nodeId].name || '',
}));

// 生成 line 数组
const generateLines = () => Object.values(state.flows).map(flow => ({
  id: flow.id,
  source: {
    arrow: flow.sourcePort,  // Top/Right/Bottom/Left
    id: flow.source
  },
  target: {
    arrow: flow.targetPort,
    id: flow.target
  },
}));
```

## 三、画布数据转 X6 渲染数据

### 3.1 核心函数：graphToJson

**文件位置**：`frontend/src/utils/graphJson.js`

```javascript
export const graphToJson = (canvasData) => {
  const { locations, lines, canvasMode } = canvasData;

  // 1. 生成节点 Cell
  const nodeCell = locations.reduce((acc, cur) => {
    const { id, x, y, type } = cur;
    const isTaskNode = ['tasknode', 'subflow'].includes(type);

    const cell = {
      id,
      shape: 'custom-node',
      position: { x, y },
      size: {
        height: isTaskNode ? 54 : 34,
        width: isTaskNode ? 154 : 34,
      },
      data: {
        ...cur,
        type: nodeCompMap[type],  // 类型映射
      },
    };
    acc.push(cell);
    return acc;
  }, []);

  // 2. 生成连线 Cell
  const edgeCell = lines.reduce((acc, cur) => {
    const { id, source, target } = cur;
    acc.push({
      shape: 'edge',
      id,
      source: {
        cell: source.id,
        port: `port_${source.arrow.toLowerCase()}`,  // port_top/port_right/port_bottom/port_left
      },
      target: {
        cell: target.id,
        port: `port_${target.arrow.toLowerCase()}`,
      },
      attrs: {
        line: {
          stroke: '#a9adb6',
          strokeWidth: 2,
          targetMarker: {
            name: 'block',
            width: 6,
            height: 8,
          },
        },
      },
      router: {
        name: 'manhattan',  // 曼哈顿路由算法
        args: { padding: 1 },
      },
    });
    return acc;
  }, []);

  return [...nodeCell, ...edgeCell];
};
```

### 3.2 节点类型映射

```javascript
const nodeCompMap = {
  startpoint: 'start',
  endpoint: 'end',
  start: 'start',
  end: 'end',
  tasknode: 'task',
  subflow: 'subflow',
  branchgateway: 'branch-gateway',
  parallelgateway: 'parallel-gateway',
  conditionalparallelgateway: 'conditional-parallel-gateway',
  convergegateway: 'converge-gateway',
};
```

## 四、后端自动布局算法

### 4.1 核心函数：draw_pipeline

**文件位置**：`bkflow/pipeline_web/drawing_new/drawing.py`

```python
def draw_pipeline(pipeline, activity_size=(150, 54), event_size=(44, 44),
                  gateway_size=(34, 34), start=(60, 100), canvas_width=1300):
    """
    将后台 pipeline tree 转换成带前端 location、line 画布信息的数据

    参数:
        pipeline: 后台流程树
        activity_size: 任务节点长宽
        event_size: 事件节点长宽
        gateway_size: 网关节点长宽
        start: 开始节点绝对定位X、Y轴坐标
        canvas_width: 画布最大宽度
    """
    # 1. 数据格式化
    normalize.normalize_run(pipeline)

    # 2. 删除自环边
    self_edges = acyclic.remove_self_edges(pipeline)

    # 3. 逆转反向边（处理环路）
    reversed_flows = acyclic.acyclic_run(pipeline)

    # 4. 使用紧凑树算法分配 rank（层级）
    ranks = tight_tree.tight_tree_ranker(pipeline)

    # 5. 使用虚拟节点替换长边
    real_flows_chain = replace_long_path_with_dummy(pipeline, ranks)

    # 6. 使用中位数法分配层级内节点顺序，减少交叉
    orders = order.ordering(pipeline, ranks)

    # 7. 计算每个节点应该填充的节点数量
    nodes_fill_nums = compute_nodes_fill_num(pipeline, orders)

    # 8. 还原自环边
    acyclic.insert_self_edges(pipeline, self_edges)

    # 9. 根据 orders 分配位置
    locations, lines = position.position(
        pipeline=pipeline,
        orders=orders,
        activity_size=activity_size,
        event_size=event_size,
        gateway_size=gateway_size,
        start=start,
        canvas_width=canvas_width,
        more_flows={**real_flows_chain, **reversed_flows},
        nodes_fill_nums=nodes_fill_nums,
    )

    # 10. 删除虚拟节点并恢复长边
    remove_dummy(pipeline, real_flows_chain,
                 dummy_nodes_included=[locations],
                 dummy_flows_included=[lines])

    # 11. 恢复反向边
    acyclic.acyclic_undo(pipeline, reversed_flows)

    # 12. 数据格式还原
    normalize.normalize_undo(pipeline)

    # 13. 添加画布信息到 pipeline
    pipeline.update({
        "location": list(locations.values()),
        "line": list(lines.values())
    })
```

### 4.2 后端布局算法步骤详解

#### 步骤1：数据格式化
将 pipeline tree 转换为内部处理格式，统一数据结构。

#### 步骤2：删除自环边
检测并临时删除自环边（节点指向自己的边），避免影响布局算法。

#### 步骤3：逆转反向边
检测环路并逆转反向边，将有向图转换为 DAG（有向无环图）。

#### 步骤4：分配 Rank（层级）
使用紧凑树算法为每个节点分配层级（rank），同一层级的节点在同一水平线上。

```python
# 示例 rank 分配
ranks = {
    0: ['start_node'],           # 第0层：开始节点
    1: ['task1'],                # 第1层：第一个任务
    2: ['gateway1'],             # 第2层：分支网关
    3: ['task2', 'task3'],       # 第3层：并行任务
    4: ['converge1'],            # 第4层：汇聚网关
    5: ['end_node'],             # 第5层：结束节点
}
```

#### 步骤5：替换长边
如果两个节点之间的 rank 差距大于1，插入虚拟节点，避免连线过长。

```python
# 原始：node1 (rank=0) -> node2 (rank=3)
# 插入虚拟节点后：
# node1 (rank=0) -> dummy1 (rank=1) -> dummy2 (rank=2) -> node2 (rank=3)
```

#### 步骤6：层级内排序
使用中位数法对每一层内的节点进行排序，减少连线交叉。

#### 步骤7：计算填充数量
计算每个节点需要填充的空白数量，用于调整节点间距。

#### 步骤8-13：还原和输出
还原之前的临时修改，生成最终的 location 和 line 数据。

### 4.3 后端输出格式

```python
# location 格式
locations = {
    "node_id": {
        "id": "node_id",
        "type": "tasknode",      # 前端类型
        "name": "节点名称",
        "x": 240,
        "y": 150,
        "group": "",
        "icon": ""
    }
}

# line 格式
lines = {
    "line_id": {
        "id": "line_id",
        "source": {
            "arrow": "Right",
            "id": "source_node_id"
        },
        "target": {
            "arrow": "Left",
            "id": "target_node_id"
        }
    }
}
```

## 五、完整转换示例

### 5.1 输入：Pipeline Tree

```json
{
  "start_event": {
    "id": "n001",
    "type": "EmptyStartEvent",
    "incoming": "",
    "outgoing": "l001"
  },
  "activities": {
    "n002": {
      "id": "n002",
      "type": "ServiceActivity",
      "name": "任务1",
      "incoming": ["l001"],
      "outgoing": "l002"
    },
    "n004": {
      "id": "n004",
      "type": "ServiceActivity",
      "name": "任务2",
      "incoming": ["l003"],
      "outgoing": "l005"
    },
    "n005": {
      "id": "n005",
      "type": "ServiceActivity",
      "name": "任务3",
      "incoming": ["l004"],
      "outgoing": "l006"
    }
  },
  "gateways": {
    "n003": {
      "id": "n003",
      "type": "ExclusiveGateway",
      "name": "分支",
      "incoming": "l002",
      "outgoing": ["l003", "l004"]
    },
    "n006": {
      "id": "n006",
      "type": "ConvergeGateway",
      "name": "汇聚",
      "incoming": ["l005", "l006"],
      "outgoing": "l007"
    }
  },
  "flows": {
    "l001": { "id": "l001", "source": "n001", "target": "n002" },
    "l002": { "id": "l002", "source": "n002", "target": "n003" },
    "l003": { "id": "l003", "source": "n003", "target": "n004" },
    "l004": { "id": "l004", "source": "n003", "target": "n005" },
    "l005": { "id": "l005", "source": "n004", "target": "n006" },
    "l006": { "id": "l006", "source": "n005", "target": "n006" },
    "l007": { "id": "l007", "source": "n006", "target": "n007" }
  },
  "end_event": {
    "id": "n007",
    "type": "EmptyEndEvent",
    "incoming": ["l007"],
    "outgoing": ""
  }
}
```

### 5.2 输出：画布数据

```json
{
  "location": [
    { "id": "n001", "type": "startpoint", "name": "", "x": 40, "y": 134 },
    { "id": "n002", "type": "tasknode", "name": "任务1", "x": 120, "y": 120 },
    { "id": "n003", "type": "branchgateway", "name": "分支", "x": 320, "y": 134 },
    { "id": "n004", "type": "tasknode", "name": "任务2", "x": 528, "y": 100 },
    { "id": "n005", "type": "tasknode", "name": "任务3", "x": 528, "y": 200 },
    { "id": "n006", "type": "convergegateway", "name": "汇聚", "x": 728, "y": 134 },
    { "id": "n007", "type": "endpoint", "name": "", "x": 808, "y": 134 }
  ],
  "line": [
    { "id": "l001", "source": { "id": "n001", "arrow": "Right" }, "target": { "id": "n002", "arrow": "Left" } },
    { "id": "l002", "source": { "id": "n002", "arrow": "Right" }, "target": { "id": "n003", "arrow": "Left" } },
    { "id": "l003", "source": { "id": "n003", "arrow": "Right" }, "target": { "id": "n004", "arrow": "Left" } },
    { "id": "l004", "source": { "id": "n003", "arrow": "Bottom" }, "target": { "id": "n005", "arrow": "Left" } },
    { "id": "l005", "source": { "id": "n004", "arrow": "Right" }, "target": { "id": "n006", "arrow": "Bottom" } },
    { "id": "l006", "source": { "id": "n005", "arrow": "Right" }, "target": { "id": "n006", "arrow": "Bottom" } },
    { "id": "l007", "source": { "id": "n006", "arrow": "Right" }, "target": { "id": "n007", "arrow": "Left" } }
  ]
}
```

## 六、关键算法总结

### 6.1 前端布局算法特点

1. **递归布局**：从开始节点递归遍历整个流程图
2. **分支优化**：按深度排序分支，深度大的在上方
3. **位置调整**：自动调整分支位置，避免节点重叠
4. **端点计算**：自动计算连线的源端点和目标端点位置

### 6.2 后端布局算法特点

1. **层级分配**：使用紧凑树算法分配节点层级
2. **虚拟节点**：处理长边，保持布局美观
3. **交叉最小化**：使用中位数法减少连线交叉
4. **环路处理**：检测并处理有向图中的环路

### 6.3 两种算法对比

| 特性 | 前端算法 | 后端算法 |
|-----|---------|---------|
| 实现语言 | JavaScript | Python |
| 复杂度 | 中等 | 高 |
| 适用场景 | 简单流程图 | 复杂流程图 |
| 环路处理 | 不支持 | 支持 |
| 长边处理 | 不支持 | 支持（虚拟节点） |
| 交叉优化 | 基本优化 | 高级优化（中位数法） |
